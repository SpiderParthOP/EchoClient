\
#!/usr/bin/env bash
set -euo pipefail
echo "Decompile and patch started"

# Find the uploaded zip/jar
ORIG_ZIP="original/feather-standalone-0.2.4.jar.zip"
if [ ! -f "$ORIG_ZIP" ]; then
  echo "Original zip not found at $ORIG_ZIP"
  exit 1
fi

WORKDIR=work
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR"
unzip -q "$ORIG_ZIP" -d "$WORKDIR/zip"
# Find inner jar
INNER_JAR=$(find "$WORKDIR/zip" -type f -name "*.jar" | head -n 1 || true)
if [ -z "$INNER_JAR" ]; then
  # maybe the zip itself is the jar structure; rezip contents
  (cd "$WORKDIR/zip" && zip -q -r ../inner.jar .)
  INNER_JAR="$WORKDIR/inner.jar"
fi
echo "Inner jar: $INNER_JAR"

# Decompile with CFR (download jar)
CFR_JAR=cfr.jar
if [ ! -f "$CFR_JAR" ]; then
  echo "Downloading CFR decompiler..."
  curl -L -o "$CFR_JAR" "https://www.benf.org/other/cfr/cfr-0.152.jar"
fi

rm -rf src_decompiled
java -jar "$CFR_JAR" --outputdir src_decompiled "$INNER_JAR"

# Basic package rename: from net.digitalingot.* to com.spiderparth.echoclient.*
echo "Patching packages and identifiers..."
find src_decompiled -type f -name "*.java" -print0 | xargs -0 sed -i 's/net.digitalingot/com.spiderparth.echoclient/g' || true
find src_decompiled -type f -name "*.java" -print0 | xargs -0 sed -i 's/feather/echoclient/g' || true

# Move decompiled sources into project src/main/java
mkdir -p src/main/java
rsync -a src_decompiled/ src/main/java/

# Patch fabric.mod.json (already included in resources but ensure correct fields)
python3 - <<'PY'
import json
p = "src/main/resources/fabric.mod.json"
try:
    with open(p,"r") as f:
        j = json.load(f)
except FileNotFoundError:
    j = {}
j.update({
  "id": "echo-client",
  "name": "Echo Client",
  "version": "1.0.0-1.21.5",
  "authors": ["SpiderParthOP"],
  "environment": "client",
  "entrypoints": {"client": ["com.spiderparth.echoclient.EchoClientMod"]},
  "depends": {"fabricloader": ">=0.16.0", "fabric-api": "*", "minecraft": "1.21.5"}
})
open(p,"w").write(json.dumps(j, indent=2))
PY

echo "Decompile and patch complete."
