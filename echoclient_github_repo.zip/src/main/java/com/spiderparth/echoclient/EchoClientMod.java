package com.spiderparth.echoclient;

// Placeholder main class. The decompiler+patch script will overwrite 
// src/main/java with actual decompiled sources pulled from the uploaded jar.
public class EchoClientMod {
    // decompiled source will replace this file
}
