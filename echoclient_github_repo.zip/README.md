# Echo Client - GitHub Actions Port Pipeline

This repository is a GitHub-ready scaffold to port the uploaded `feather-standalone-0.2.4.jar.zip` into a working **Echo Client** mod for **Minecraft 1.21.5 (Fabric)** using GitHub Actions CI.

**What this repo does (automated in Actions):**
1. Unzips `original/feather-standalone-0.2.4.jar.zip` and extracts the inner JAR.
2. Decompiles classes into Java sources using CFR.
3. Applies automated package and identifier renames to `com.spiderparth.echoclient`.
4. Patches `fabric.mod.json` to target Minecraft 1.21.5 and Echo Client metadata.
5. Runs `./gradlew build` (Fabric Loom) to build the mod jar.
6. Publishes `EchoClient-1.21.5.jar` as a workflow artifact for download.

## How to use (mobile-friendly)
1. Create a new **public** GitHub repository (name it `echo-client-port` or similar).
2. Upload the contents of this ZIP as the repository files (use GitHub mobile UI -> Add file -> Upload files). Upload the entire ZIP contents, **not** the ZIP file itself.
3. Commit the files to the default branch (`main` or `master`). GitHub Actions will start automatically.
4. Open the "Actions" tab for the repo. Click the running workflow and wait for it to finish.
5. When finished, download the artifact called `echoclient-jar` from the workflow run — that's your mod jar to drop into Mojo/Zalith `/mods/`.

If the workflow fails, open the log and copy the failure link/lines and send them to me — I'll patch the workflow or source and push an update until it builds cleanly.

Notes:
- The decompilation and automated fixes are heuristics. Complex mixins or obfuscated references may need manual fixes; I'll iterate until successful if you share the build logs.
- The workflow uses Java 17 toolchain and Fabric Loom in the runner to build the final jar.
